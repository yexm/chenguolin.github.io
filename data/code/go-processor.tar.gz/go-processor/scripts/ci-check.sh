#!/bin/bash

gocyclo() {
    echo '********** gocyclo check start ... **********'

    # golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=gocyclo
    errors=$(golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=gocyclo)

    # grep errors has go file
    echo "${errors}" | grep "\.go"

    # $? equal 0 found check error
    if [ $? -eq 0 ]; then
        echo '********** gocyclo check failed ~ **********'
        echo "${errors}"
        exit 1
    else
        echo '********** gocyclo check ok ~ **********'
    fi
}

gofmt() {
    echo '********** gofmt check start ... **********'

    # golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=gofmt
    errors=$(golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=gofmt)

    # grep errors has go file
    echo "${errors}" | grep "\.go"

    # $? equal 0 found check error
    if [ $? -eq 0 ]; then
        echo '********** gofmt check failed ~ **********'
        echo "${errors}"
        exit 1
    else
        echo '********** gofmt check ok ~ **********'
    fi
}

golint() {
    echo '********** golint check start ... **********'

    # golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=golint
    errors=$(golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=golint)

    # grep errors has go file
    echo "${errors}" | grep "\.go"

    # $? equal 0 found check error
    if [ $? -eq 0 ]; then
        echo '********** golint check failed ~ **********'
        echo "${errors}"
        exit 1
    else
        echo '********** golint check ok ~ **********'
    fi
}

gosimple() {
    echo '********** gosimple check start ... **********'

    # golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=gosimple
    errors=$(golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=gosimple)

    # grep errors has go file
    echo "${errors}" | grep "\.go"

    # $? equal 0 found check error
    if [ $? -eq 0 ]; then
        echo '********** gosimple check failed ~ **********'
        echo "${errors}"
        exit 1
    else
        echo '********** gosimple check ok ~ **********'
    fi
}

gotest() {
    echo '********** go test check start ... **********'

    # go test
    errors=$(go list ./... | grep -v vendor | xargs -n 1 go test)

    # grep errors has FAIL
    echo "${errors}" | grep "FAIL"

    if [ $? -eq 0 ]; then
        echo '********** go test check failed ~ **********'
        echo "${errors}"
        exit 1
    else
        echo "${errors}"
        echo '********** go test check ok ~ **********'
    fi
}

govet() {
    echo '********** go vet check start ... **********'

    # golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=govet --enable=errcheck --enable=staticcheck --enable=typecheck --enable=bodyclose
    errors=$(golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=govet --enable=errcheck --enable=staticcheck --enable=typecheck --enable=bodyclose)

    # grep errors has go file
    echo "${errors}" | grep -E "\.go|package"

    # $? equal 0 has error
    if [ $? -eq 0 ]; then
        echo '********** go vet check failed ~ **********'
        echo ${errors}
        exit 1
    else
        echo '********** go vet check ok ~ **********'
    fi
}

misspell() {
    echo '********** misspell check start ... **********'

    # golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=misspell
    errors=$(golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=misspell)

    # grep errors has go file
    echo "${errors}" | grep "\.go"

    # $? equal 0 found check error
    if [ $? -eq 0 ]; then
        echo '********** misspell check failed ~ **********'
        echo "${errors}"
        exit 1
    else
        echo '********** misspell check ok ~ **********'
    fi
}

unused() {
    #!/bin/bash

    echo '********** unused code check start ... **********'

    # golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=deadcode --enable=ineffassign --enable=structcheck --enable=unused --enable=varcheck --enable=unparam
    errors=$(golangci-lint run --deadline=10m --disable-all --skip-dirs=vendor --enable=deadcode --enable=ineffassign --enable=structcheck --enable=unused --enable=varcheck --enable=unparam)

    # grep errors has go file
    echo "${errors}" | grep "\.go"

    # $? equal 0 found check error
    if [ $? -eq 0 ]; then
        echo '********** unused code check failed ~ **********'
        echo "${errors}"
        exit 1
    else
        echo '********** unused code check ok ~ **********'
    fi
}

# check first args
case $1 in
   gocyclo)
      gocyclo
      ;;
   gofmt)
      gofmt
      ;;
   golint)
      golint
      ;;
   gosimple)
      gosimple
      ;;
   gotest)
      gotest
      ;;
   govet)
      govet
      ;;
   misspell)
      misspell
      ;;
   unused)
      unused
      ;;
   *)
      gocyclo
      gofmt
      golint
      gosimple
      # gotest
      govet
      misspell
      unused
      ;;
esac


