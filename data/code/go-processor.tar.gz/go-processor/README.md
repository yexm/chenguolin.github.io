# Processor
[![CircleCI](https://circleci.com/gh/chenguolin/go-processor.svg?style=svg)](https://circleci.com/gh/chenguolin/go-processor)
[![Go Report Card](https://goreportcard.com/badge/github.com/chenguolin/go-processor)](https://goreportcard.com/report/github.com/chenguolin/go-processor)

使用`CircleCI`进程CI Pipeline校验，`Go Report Card`进行Golang项目代码分析
1. CircleCI: https://circleci.com/gh/chenguolin/go-processor/tree/master
2. Go Report Card: https://goreportcard.com/report/github.com/chenguolin/go-processor

如果要实现新的processor只需要在handle目录下参考现有的mysql、kafka实现scanner和handle即可

1. processor 包含3个go文件
   * processor: Processor struct
   * scanner: scanner interface
   * handle: handle interface
2. handle/mysql mysql processor
   * scanner: mysql scanner
   * handle: mysql handle
3. handle/kafka kafka processor
   * scanner: kafka scanner
   * handle: kafka handle

# Sample
```
func main() {
    log.Info("Start processor ...")

    // mysql processor
    maxChanSize := 50
    scanInterval := 5 * time.Second
    // dbProxy := db.NewMysql(nil)
    mysqlScanner := mysql.NewScanner(maxChanSize, scanInterval, nil)
    mysqlHandle := mysql.NewHandle()
    // 并发数
    concurrentCnt := 4
    mysqlProcessor := processor.NewProcessor(mysqlScanner, mysqlHandle, concurrentCnt)
    mysqlProcessor.Start()
    log.Info("start mysql processor ...")

    // kafka processor
    maxChanSize = 100
    brokers := "127.0.0.1:2181"
    topic := "test_topic"
    groupID := "test_consumer_group"
    kafkaScanner := kafka.NewKafkaScanner(brokers, topic, groupID, maxChanSize)
    kafkaHandle := kafka.NewHandle()
    // 并发数
    concurrentCnt = 2
    kafkaProcessor := processor.NewProcessor(kafkaScanner, kafkaHandle, concurrentCnt)
    kafkaProcessor.Start()
    log.Info("start kafka processor ...")

    // wait shutdown
    stopChan := make(chan struct{}, 1)
    registerSignal(stopChan)
    <-stopChan

    // 需要保证主进程退出之前 processor channel里数据需要被完全处理
    // stop mysql processor
    mysqlProcessor.Stop()
    log.Info("mysql processor stop successful ~")

    // 需要保证主进程退出之前 processor channel里数据需要被完全处理
    // stop kafka processor
    kafkaProcessor.Stop()
    log.Info("kafka processor stop successful ~")

    log.Info("Shutdown processor ~")
}

// registerSignal register kill signal
func registerSignal(shutdown chan struct{}) {
    c := make(chan os.Signal)
    signal.Notify(c, os.Interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM)

    go func() {
	defer func() {
	    if err := recover(); err != nil {
		log.Error("[registerSignal] panic error: ",
			log.Object("error", err))	
		debug.PrintStack()
	    }
	}()

	for sig := range c {
	    // close shutdown channel
	    close(shutdown)
	    log.Info("[registerSignal] receive system signal:" +
		sig.String() + ", going to shutdown ...")
	    return
	}
    }()
}
```

# CI Check Workflow
1. `gocyclo`: 校验代码复杂度
2. `gofmt`: 校验代码是否都已经格式化
3. `golint`: 校验代码风格规范是否按照指定标准
4. `gosimple`: 校验代码是否可以简化
5. `govet`: 代码静态校验
6. `misspell`: 校验是否有英文单词拼写错误
7. `unused`: 校验是否有未使用变量、常量、函数、结构体等
8. `gotest`: 单元测试校验

# Gitlab CI
如果使用Gitlab，也可以通过`.gitlab-ci.yml`运行Gitlab CI Pipeline，详细介绍请参考下面2篇文章
1. [Gitlab 安装使用](https://chenguolin.github.io/2018/12/18/Git-Gitlab-%E5%AE%89%E8%A3%85%E4%BD%BF%E7%94%A8/)
2. [Gitlab CI和CD配置](https://chenguolin.github.io/2018/12/24/Git-Gitlab-CI%E5%92%8CCD%E9%85%8D%E7%BD%AE/)


