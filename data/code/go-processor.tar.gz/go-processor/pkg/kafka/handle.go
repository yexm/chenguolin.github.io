// Package kafka handle process
// Created by chenguolin 2019-01-13
package kafka

import (
	"fmt"

	"github.com/chenguolin/go-processor/processor"
)

// Handle kafka pkg
type Handle struct {
	// TODO
}

// NewHandle new kafka pkg
func NewHandle() *Handle {
	return &Handle{}
}

// Process kafka record process
func (h *Handle) Process(record processor.Record) {
	// TODO record can convert 2 any type
	// TODO type message struct {
	// TODO    name string
	// TODO    age  int
	// TODO }
	// TODO msg, ok := record.(message)
	fmt.Println(record)
}
