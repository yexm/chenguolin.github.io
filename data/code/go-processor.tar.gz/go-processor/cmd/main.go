// Package main for processor entry point
// Created by chenguolin 2019-01-13
package main

import (
	"fmt"
	"os"
	"os/signal"
	"runtime/debug"
	"syscall"
	"time"

	"github.com/chenguolin/go-log/log"
	"github.com/chenguolin/go-mysql/mysql"
	"github.com/chenguolin/go-processor/config"
	"github.com/chenguolin/go-processor/pkg/kafka"
	hmysql "github.com/chenguolin/go-processor/pkg/mysql"
	"github.com/chenguolin/go-processor/processor"
)

func main() {
	log.Info("Start processor ...")

	// 1. get ENV CLUSTER_STAGE value
	clusterStage := os.Getenv("CLUSTER_STAGE")
	if clusterStage == "" {
		panic("os.Getenv get CLUSTER_STAGE value is empty")
	}

	// 2. load config file
	configFile := fmt.Sprintf("./%s-config.toml", clusterStage)
	conf, err := config.GetConfig(configFile)
	if err != nil {
		panic("config.GetConfig error: " + err.Error())
	}

	// 3. new mysql processor
	scanInterval := 5 * time.Second
	mysqlConf := newMysqlConf(conf.Mysql)
	dbProxy, err := mysql.NewMysql(mysqlConf)
	if err != nil {
		panic("call mysql.NewMysql error: " + err.Error())
	}

	mysqlScanner := hmysql.NewScanner(scanInterval, dbProxy)
	mysqlHandle := hmysql.NewHandle()
	// 并发数
	concurrentCnt := 4
	mysqlProcessor := processor.NewProcessor(mysqlScanner, mysqlHandle, concurrentCnt)

	log.Info("start mysql processor ...")
	mysqlProcessor.Start()

	// 4. new kafka processor
	kafkaConf := conf.Kafka
	kafkaScanner := kafka.NewKafkaScanner(kafkaConf.Brokers, kafkaConf.Topic, kafkaConf.ConsumerGroupID)
	kafkaHandle := kafka.NewHandle()
	// 并发数
	concurrentCnt = 2
	kafkaProcessor := processor.NewProcessor(kafkaScanner, kafkaHandle, concurrentCnt)

	log.Info("start kafka processor ...")
	kafkaProcessor.Start()

	// 5. wait shutdown signal
	stopChan := make(chan struct{}, 1)
	registerSignal(stopChan)
	<-stopChan

	// 6. stop mysql processor
	// 需要保证主进程退出之前 processor channel里数据需要被完全处理
	mysqlProcessor.Stop()
	log.Info("mysql processor stop successful ~")

	// 7. stop kafka processor
	// 需要保证主进程退出之前 processor channel里数据需要被完全处理
	kafkaProcessor.Stop()
	log.Info("kafka processor stop successful ~")

	log.Info("Shutdown processor ~")
}

// newMysqlConf new mysql config
func newMysqlConf(conf *config.MysqlConf) *mysql.Config {
	mysqlCfg := &mysql.Config{}
	mysqlCfg.SetMaster(conf.Master)
	mysqlCfg.SetSlaves(conf.Slaves)
	mysqlCfg.SetPort(conf.Port)
	mysqlCfg.SetUserName(conf.Username)
	mysqlCfg.SetPassword(conf.Password)
	mysqlCfg.SetDBName(conf.Dbname)
	if conf.MaxOpenConnCount > 0 {
		mysqlCfg.SetMaxOpenConnCount(conf.MaxOpenConnCount)
	}
	if conf.MaxIdleConnCount > 0 {
		mysqlCfg.SetMaxIdleConnCount(conf.MaxIdleConnCount)
	}
	if conf.ConnWaitTimeMs > 0 {
		mysqlCfg.SetConnWaitTimeMs(conf.ConnWaitTimeMs)
	}
	if conf.ConnIdleTimeMs > 0 {
		mysqlCfg.SetConnIdleTimeMs(conf.ConnIdleTimeMs)
	}
	if conf.ConnTimeoutMs > 0 {
		mysqlCfg.SetConnTimeoutMs(conf.ConnTimeoutMs)
	}
	if conf.WriteTimeoutMs > 0 {
		mysqlCfg.SetWriteTimeoutMs(conf.WriteTimeoutMs)
	}
	if conf.ReadTimeoutMs > 0 {
		mysqlCfg.SetReadTimeoutMs(conf.ReadTimeoutMs)
	}

	return mysqlCfg
}

// registerSignal register kill signal
func registerSignal(shutdown chan struct{}) {
	c := make(chan os.Signal)
	signal.Notify(c, os.Interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		defer func() {
			if err := recover(); err != nil {
				log.Error("[registerSignal] panic error: ",
					log.Object("error", err))
				debug.PrintStack()
			}
		}()

		for sig := range c {
			// close shutdown channel
			close(shutdown)
			log.Info("[registerSignal] receive system signal:" +
				sig.String() + ", going to shutdown ...")
			return
		}
	}()
}
